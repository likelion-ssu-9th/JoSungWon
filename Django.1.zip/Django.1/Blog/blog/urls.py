from django.contrib import admin
from django.urls import path
from Blog import views as blog

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', blog.home, name="home"),
    path('<str:id>', blog.detail, name="detail"),
]